<?php
echo $_POST['name']."さん、ご登録いただきありがとうございます。";